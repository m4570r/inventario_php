<?php /*********************************************************************************************************

██╗   ██╗██╗███████╗██╗    ██╗███████╗
██║   ██║██║██╔════╝██║    ██║██╔════╝
██║   ██║██║█████╗  ██║ █╗ ██║███████╗
╚██╗ ██╔╝██║██╔══╝  ██║███╗██║╚════██║
 ╚████╔╝ ██║███████╗╚███╔███╔╝███████║
  ╚═══╝  ╚═╝╚══════╝ ╚══╝╚══╝ ╚══════╝
 ██████╗ ██████╗ ██████╗ ███████╗██████╗ ███████╗
██╔═══██╗██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔════╝
██║   ██║██████╔╝██║  ██║█████╗  ██████╔╝███████╗
██║   ██║██╔══██╗██║  ██║██╔══╝  ██╔══██╗╚════██║
╚██████╔╝██║  ██║██████╔╝███████╗██║  ██║███████║
 ╚═════╝ ╚═╝  ╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝╚══════╝
░█▀▄░█▀▀░▀█▀░█▀█░▀█▀░█░░░█▀▀░░░░█░█░▀█▀░█▀▀░█░█░█▀▀░░░░█▀█░█░█░█▀█
░█░█░█▀▀░░█░░█▀█░░█░░█░░░▀▀█░░░░▀▄▀░░█░░█▀▀░█▄█░▀▀█░░░░█▀▀░█▀█░█▀▀
░▀▀░░▀▀▀░░▀░░▀░▀░▀▀▀░▀▀▀░▀▀▀░▀░░░▀░░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀░░▀░░░▀░▀░▀░░

Nombre del Archivo          : details.views.php
Directorio                  : orders
Nombre del Programador      : Miguel Angel Gonzalez
Lenguaje de Programación    : PHP
Versión                     : 1.0

Descripción:
El archivo "details.views.php" se encuentra en el directorio "orders" y es parte de una 
aplicación web desarrollada en PHP. Su función principal es mostrar detalles específicos 
de un pedido.

Funcionalidades Principales:
1. Visualización de Detalles: Muestra información detallada sobre un pedido, como los 
productos incluidos, el cliente, la fecha y otros detalles relevantes.

2. Presentación Clara: Presenta la información de manera organizada y legible para que 
los usuarios puedan obtener una visión completa del pedido.

*********************************************************************************************************/ ?>