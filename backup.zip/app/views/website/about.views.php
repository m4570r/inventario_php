<?php /*********************************************************************************************************

██╗   ██╗██╗███████╗██╗    ██╗███████╗
██║   ██║██║██╔════╝██║    ██║██╔════╝
██║   ██║██║█████╗  ██║ █╗ ██║███████╗
╚██╗ ██╔╝██║██╔══╝  ██║███╗██║╚════██║
 ╚████╔╝ ██║███████╗╚███╔███╔╝███████║
  ╚═══╝  ╚═╝╚══════╝ ╚══╝╚══╝ ╚══════╝
██╗    ██╗███████╗██████╗ ███████╗██╗████████╗███████╗
██║    ██║██╔════╝██╔══██╗██╔════╝██║╚══██╔══╝██╔════╝
██║ █╗ ██║█████╗  ██████╔╝███████╗██║   ██║   █████╗  
██║███╗██║██╔══╝  ██╔══██╗╚════██║██║   ██║   ██╔══╝  
╚███╔███╔╝███████╗██████╔╝███████║██║   ██║   ███████╗
 ╚══╝╚══╝ ╚══════╝╚═════╝ ╚══════╝╚═╝   ╚═╝   ╚══════╝
░█▀█░█▀▄░█▀█░█░█░▀█▀░░░░█░█░▀█▀░█▀▀░█░█░█▀▀░░░░█▀█░█░█░█▀█
░█▀█░█▀▄░█░█░█░█░░█░░░░░▀▄▀░░█░░█▀▀░█▄█░▀▀█░░░░█▀▀░█▀█░█▀▀
░▀░▀░▀▀░░▀▀▀░▀▀▀░░▀░░▀░░░▀░░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀░░▀░░░▀░▀░▀░░

Nombre del Archivo          : about.view.php
Directorio                  : website
Nombre del Programador      : Miguel Angel Gonzalez
Lenguaje de Programación    : PHP
Versión                     : 1.0

Descripción:
El archivo "about.view.php" se encuentra en el directorio "website" y forma parte de una 
aplicación web desarrollada en PHP. Su función principal es mostrar una página con 
información sobre la empresa o el sitio web, brindando a los visitantes una visión 
general de la organización.

Funcionalidades Principales:
1. Contenido Informativo: Contiene contenido descriptivo sobre la empresa, su historia, 
misión, visión u otros datos relevantes.

2. Elementos Visuales: Puede incluir imágenes, gráficos o elementos visuales que 
complementen la información y mejoren la presentación.

3. Navegación: Puede proporcionar enlaces de navegación que permitan a los visitantes 
acceder a otras secciones del sitio web.

*********************************************************************************************************/ ?>