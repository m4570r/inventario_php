<?php /*********************************************************************************************************

██╗   ██╗██╗███████╗██╗    ██╗███████╗
██║   ██║██║██╔════╝██║    ██║██╔════╝
██║   ██║██║█████╗  ██║ █╗ ██║███████╗
╚██╗ ██╔╝██║██╔══╝  ██║███╗██║╚════██║
 ╚████╔╝ ██║███████╗╚███╔███╔╝███████║
  ╚═══╝  ╚═╝╚══════╝ ╚══╝╚══╝ ╚══════╝
████████╗ ██████╗ ██╗  ██╗███████╗███╗   ██╗███████╗
╚══██╔══╝██╔═══██╗██║ ██╔╝██╔════╝████╗  ██║██╔════╝
   ██║   ██║   ██║█████╔╝ █████╗  ██╔██╗ ██║███████╗
   ██║   ██║   ██║██╔═██╗ ██╔══╝  ██║╚██╗██║╚════██║
   ██║   ╚██████╔╝██║  ██╗███████╗██║ ╚████║███████║
   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚══════╝
░▀█▀░█▀█░█▀▄░█▀▀░█░█░░░░█░█░▀█▀░█▀▀░█░█░█▀▀░░░░█▀█░█░█░█▀█
░░█░░█░█░█░█░█▀▀░▄▀▄░░░░▀▄▀░░█░░█▀▀░█▄█░▀▀█░░░░█▀▀░█▀█░█▀▀
░▀▀▀░▀░▀░▀▀░░▀▀▀░▀░▀░▀░░░▀░░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀░░▀░░░▀░▀░▀░░s

Nombre del Archivo          : index.view.php
Directorio                  : tokens
Nombre del Programador      : Miguel Angel Gonzalez
Lenguaje de Programación    : PHP
Versión                     : 1.0

Descripción:
El archivo "index.view.php" se encuentra en el directorio "tokens" y es parte de una 
aplicación web desarrollada en PHP. Su función principal es mostrar una lista de tokens 
o identificadores de acceso existentes, proporcionando una vista general de los tokens 
disponibles.

Funcionalidades Principales:
1. Listado de Tokens: Muestra una lista de los tokens, incluyendo detalles como el 
nombre del token y los permisos asociados.

2. Filtrado y Ordenamiento: Permite a los usuarios filtrar y ordenar la lista de tokens 
para facilitar la búsqueda de tokens específicos.

3. Enlaces de Edición y Eliminación: Proporciona enlaces para editar o eliminar tokens 
individualmente, lo que permite a los usuarios realizar acciones adicionales.

4. Navegación entre Páginas: Implementa paginación para dividir la lista en páginas más 
manejables si la lista es extensa.

Estos archivos son parte de la interfaz de usuario de la aplicación y contribuyen a la 
creación, edición y visualización de tokens o identificadores de acceso en el sistema.

*********************************************************************************************************/ ?>