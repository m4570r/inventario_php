<?php /*********************************************************************************************************

██╗   ██╗██╗███████╗██╗    ██╗███████╗
██║   ██║██║██╔════╝██║    ██║██╔════╝
██║   ██║██║█████╗  ██║ █╗ ██║███████╗
╚██╗ ██╔╝██║██╔══╝  ██║███╗██║╚════██║
 ╚████╔╝ ██║███████╗╚███╔███╔╝███████║
  ╚═══╝  ╚═╝╚══════╝ ╚══╝╚══╝ ╚══════╝
██████╗ ██████╗  ██████╗ ██████╗ ██╗   ██╗ ██████╗████████╗███████╗
██╔══██╗██╔══██╗██╔═══██╗██╔══██╗██║   ██║██╔════╝╚══██╔══╝██╔════╝
██████╔╝██████╔╝██║   ██║██║  ██║██║   ██║██║        ██║   ███████╗
██╔═══╝ ██╔══██╗██║   ██║██║  ██║██║   ██║██║        ██║   ╚════██║
██║     ██║  ██║╚██████╔╝██████╔╝╚██████╔╝╚██████╗   ██║   ███████║
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═════╝  ╚═════╝  ╚═════╝   ╚═╝   ╚══════╝
░▀█▀░█▀█░█▀▄░█▀▀░█░█░░░░█░█░▀█▀░█▀▀░█░█░█▀▀░░░░█▀█░█░█░█▀█
░░█░░█░█░█░█░█▀▀░▄▀▄░░░░▀▄▀░░█░░█▀▀░█▄█░▀▀█░░░░█▀▀░█▀█░█▀▀
░▀▀▀░▀░▀░▀▀░░▀▀▀░▀░▀░▀░░░▀░░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀░░▀░░░▀░▀░▀░░s

Nombre del Archivo          : index.view.php
Directorio                  : products
Nombre del Programador      : Miguel Angel Gonzalez
Lenguaje de Programación    : PHP
Versión                     : 1.0

Descripción:
El archivo "index.view.php" se encuentra en el directorio "products" y forma parte de 
una aplicación web desarrollada en PHP. Su función principal es mostrar una lista de 
productos registrados en el sistema, proporcionando a los usuarios una vista general 
de los productos disponibles.

Funcionalidades Principales:
1. Listado de Productos: Muestra una lista de productos registrados, incluyendo detalles 
como el nombre, la descripción, el precio, la categoría, etc.

2. Filtrado y Ordenamiento: Permite a los usuarios filtrar y ordenar la lista de 
productos para facilitar la búsqueda de productos específicos.

3. Enlaces de Edición y Eliminación: Proporciona enlaces para editar o eliminar 
productos individualmente, lo que permite a los usuarios realizar acciones adicionales.

4. Navegación entre Páginas: Si la lista es extensa, implementa la navegación entre 
páginas para visualizar productos adicionales.

5. Resumen de Stock: Ofrece un resumen del stock disponible de cada producto para 
fines de gestión y

*********************************************************************************************************/ ?>