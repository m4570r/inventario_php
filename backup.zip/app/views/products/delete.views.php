<?php /*********************************************************************************************************

██╗   ██╗██╗███████╗██╗    ██╗███████╗
██║   ██║██║██╔════╝██║    ██║██╔════╝
██║   ██║██║█████╗  ██║ █╗ ██║███████╗
╚██╗ ██╔╝██║██╔══╝  ██║███╗██║╚════██║
 ╚████╔╝ ██║███████╗╚███╔███╔╝███████║
  ╚═══╝  ╚═╝╚══════╝ ╚══╝╚══╝ ╚══════╝
██████╗ ██████╗  ██████╗ ██████╗ ██╗   ██╗ ██████╗████████╗███████╗
██╔══██╗██╔══██╗██╔═══██╗██╔══██╗██║   ██║██╔════╝╚══██╔══╝██╔════╝
██████╔╝██████╔╝██║   ██║██║  ██║██║   ██║██║        ██║   ███████╗
██╔═══╝ ██╔══██╗██║   ██║██║  ██║██║   ██║██║        ██║   ╚════██║
██║     ██║  ██║╚██████╔╝██████╔╝╚██████╔╝╚██████╗   ██║   ███████║
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═════╝  ╚═════╝  ╚═════╝   ╚═╝   ╚══════╝
░█▀▄░█▀▀░█░░░█▀▀░▀█▀░█▀▀░░░░█░█░▀█▀░█▀▀░█░█░█▀▀░░░░█▀█░█░█░█▀█
░█░█░█▀▀░█░░░█▀▀░░█░░█▀▀░░░░▀▄▀░░█░░█▀▀░█▄█░▀▀█░░░░█▀▀░█▀█░█▀▀
░▀▀░░▀▀▀░▀▀▀░▀▀▀░░▀░░▀▀▀░▀░░░▀░░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀░░▀░░░▀░▀░▀░░

Nombre del Archivo          : delete.views.php
Directorio                  : products
Nombre del Programador      : Miguel Angel Gonzalez
Lenguaje de Programación    : PHP
Versión                     : 1.0

Descripción:
El archivo "delete.views.php" se encuentra en el directorio "products" y es parte de una 
aplicación web desarrollada en PHP. Su función principal es permitir a los usuarios 
eliminar productos o artículos del sistema.

Funcionalidades Principales:
1. Eliminación de Productos: Proporciona una interfaz que permite a los usuarios 
seleccionar y eliminar productos específicos de su inventario o catálogo.

2. Confirmación de Eliminación: Debe incluir una confirmación para evitar eliminaciones 
accidentales y garantizar que el usuario confirme su acción.

3. Interfaz Amigable: Ofrece una interfaz de usuario intuitiva y fácil de usar para 
simplificar el proceso de eliminación.

*********************************************************************************************************/ ?>